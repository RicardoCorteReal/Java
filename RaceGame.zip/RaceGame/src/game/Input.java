package game;


import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Input implements KeyListener {


    private Game gameInstance
            ;


    public Input(Game game){
        gameInstance = game;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        System.out.println(key +" And Constant is " +e.VK_W);

        // FORWARD PLAYER ONE
        if (key == e.VK_W){
           gameInstance.changeVelocity(true);
           gameInstance.playerOneForward = true;
        }
        // LEFT PLAYER ONE
        if (key == e.VK_A){
            gameInstance.playerOneRotateLeft = true;
        }
        // BACKWARDS PLAYER ONE
        if (key == e.VK_S){
            gameInstance.changeVelocity(true);
            gameInstance.playerOneForward = false;
        }
        // RIGHT PLAYER ONE
        if (key == e.VK_D){
           gameInstance.playerOneRotateRight = true;
        }

        // FORWARD PLAYER TWO
        if (key == e.VK_UP){
            gameInstance.changeVelocity(false);
            gameInstance.playerTwoForward = true;
        }
        // LEFT PLAYER TWO
        if (key == e.VK_LEFT){
            gameInstance.isRotatingLeft = true;
        }
        // BACKWARDS PLAYER TWO
        if (key == e.VK_DOWN){
            gameInstance.changeVelocity(false);
            gameInstance.playerTwoForward = false;
        }
        // RIGHT PLAYER TWO
        if (key == e.VK_RIGHT){
            gameInstance.isRotatingRight = true;
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();
        System.out.println(key +" And Constant is " +e.VK_W);

        // FORWARD PLAYER ONE
        if (key == e.VK_W){
            gameInstance.resetVelocity(true);
        }
        // LEFT PLAYER ONE
        if (key == e.VK_A){
            gameInstance.playerOneRotateLeft = false;
        }
        // BACKWARDS PLAYER ONE
        if (key == e.VK_S){
            gameInstance.resetVelocity(true);
        }
        // RIGHT PLAYER ONE
        if (key == e.VK_D){
            gameInstance.playerOneRotateRight = false;
        }

        // FORWARD PLAYER TWO
        if (key == e.VK_UP) {
            gameInstance.resetVelocity(false);
        }
        // LEFT PLAYER TWO
        if (key == e.VK_LEFT){
            gameInstance.isRotatingLeft = false;
        }
        // BACKWARDS PLAYER TWO
        if (key == e.VK_DOWN){
            gameInstance.resetVelocity(false);
        }
        // RIGHT PLAYER TWO
        if (key == e.VK_RIGHT){
            gameInstance.isRotatingRight = false;
        }
        }
}
