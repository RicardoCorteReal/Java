package game;

import java.awt.*;

public class Player {
    private int xPos = 0;
    private int yPos = 0;
    private double velocityX = 0;
    private double velocityY = 0;


    private Image carGraphics;
    private int rotation = -90;

    public Player(int xPos, int yPos, double velocityX, double velocityY, Image carGraphics, int rotation) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.velocityX = velocityX;
        this.velocityY = velocityY;
        this.carGraphics = carGraphics;
        this.rotation = rotation;
    }

    public Player() {
    }

    public int getxPos() {
        return xPos;
    }

    public int getyPos() {
        return yPos;
    }

    public double getVelocityX() {
        return velocityX;
    }

    public double getVelocityY() {
        return velocityY;
    }

    public Image getCarGraphics() {
        return carGraphics;
    }

    public int getRotation() {
        return rotation;
    }

    public void setxPos(int xPos) {
        this.xPos = xPos;
    }

    public void setyPos(int yPos) {
        this.yPos = yPos;
    }

    public void setVelocityX(double velocityX) {
        this.velocityX = velocityX;
    }

    public void setVelocityY(double velocityY) {
        this.velocityY = velocityY;
    }

    public void setCarGraphics(Image carGraphics) {
        this.carGraphics = carGraphics;
    }

    public void setRotation(int rotation) {
        if (rotation >=360){
            rotation = rotation - 360;
        }
        if (rotation <= 0){
            rotation = rotation + 360;
        }
        this.rotation = rotation;


    }
}
