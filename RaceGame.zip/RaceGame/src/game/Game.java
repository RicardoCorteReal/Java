package game;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferStrategy;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

public class Game extends Canvas implements Runnable {
	public static final int WIDTH = 850;
	public static final int HEIGHT = 650;
	public static final int SCALE = 2;
	
	private Thread thread;
	private boolean isRunning = false;
	private Graphics2D g;
	private Image car;
	private Player player1;
	private Player player2;
	private AffineTransform transform;
	public boolean isRotatingLeft = false;
	public boolean isRotatingRight = false;
	public boolean playerOneRotateLeft = false;
	public boolean playerOneRotateRight = false;
	public boolean playerOneForward = false;
	public boolean playerTwoForward = false;
	public Game() {
		setSize(WIDTH,HEIGHT);
		try {
			player1 = new Player(
					425,
					500,
					0,
					0,
					getImage("/car2.png"),
					270
			);
			player2 = new Player(
					425,
					550,
					0,
					0,
					getImage("/car1.png"),
					270
			);
			car = getImage("/car2.png");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	public synchronized void start() {
		if (isRunning) {
			return;
		}
		isRunning = true;
		thread = new Thread(this);
		thread.start();
	}
	
	public synchronized void stop() {
		if (!isRunning) {
			return;
		}
		isRunning = false;
		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void run() {
		
		long timeThen = System.nanoTime();
		double frames = 60.0;
		double nanoSeconds = 1000000000 / frames;
		double delta = 0;
		long timer = System.currentTimeMillis();
		int framesPerSecond = 0;
		int updates  = 0;
		while(isRunning) {
			long now = System.nanoTime();
			delta += (now - timeThen) /nanoSeconds;
			timeThen = now;
			while (delta >=1) {
				update();
				
				updates++;
				delta --;		
			}
			render();
			framesPerSecond ++;
			
			if(System.currentTimeMillis() - timer > 1000) {
		        timer += 1000;
		        System.out.println(updates +" Ticks and frames are " + framesPerSecond);
		        framesPerSecond = 0;
		        updates = 0;
			}
		}
		stop();
	}

	private void update() {
		if (playerOneRotateLeft){
			rotateLeft(true);
		}
		if (playerOneRotateRight){
			rotateRight(true);
		}
		if (isRotatingLeft){
			rotateLeft(false);
		}
		if (isRotatingRight){
			rotateRight(false);
		}
		System.out.println(player1.getRotation());
		if (playerOneForward){
			movePlayer(true,true);
		}
		if (!playerOneForward){
			movePlayer(true,false);
		}
		if (playerTwoForward){
			movePlayer(false,true);
		}
		if (!playerTwoForward){
			movePlayer(false,false);
		}

	}

	private void render() {
		BufferStrategy bs = this.getBufferStrategy();
		if (bs == null) {
			this.createBufferStrategy(3);
			return;
		}
		g = (Graphics2D) bs.getDrawGraphics();
		/////////////////////////////

		drawTrack();
		drawPlayer1();
		drawPlayer2();

		////////////////////////////
		bs.show();
		g.dispose();

		
	}
	private void drawPlayer1(){
		transform = AffineTransform.getTranslateInstance(player1.getxPos(),player1.getyPos());
		transform.rotate(Math.toRadians(player1.getRotation()) ,25 ,25);
		g.drawImage(player1.getCarGraphics(),transform,null);
	}
	private void drawPlayer2(){
		transform = AffineTransform.getTranslateInstance(player2.getxPos(),player2.getyPos());
		transform.rotate(Math.toRadians(player2.getRotation()) ,25 ,25);
		g.drawImage(player2.getCarGraphics(),transform,null);
	}
	private void drawTrack() {
		// create a background
		g.setColor(Color.black);
		g.fillRect(0,0,WIDTH,HEIGHT);

		Color c1 = Color.green;
		g.setColor( c1 );
		g.fillRect( 150, 200, 550, 300 ); //grass 
		 
		 Color c2 = Color.yellow;
		 g.setColor( c2 ); // this was black
		 g.drawRect(50, 100, 750, 500);  // outer edge  g.drawRect(150, 200, 550, 300); // inner edge 
		 
		  Color c3 = Color.red;
		  g.setColor( c3 ); // this was yellow
		        g.drawRect( 100, 150, 650, 400 ); // mid-lane marker 
		 
		  Color c4 = Color.white;
		  g.setColor( c4 );
		  g.drawLine( 425, 500, 425, 600 ); // start line 
	}
	private Image getImage(String path) throws IOException {
		return ImageIO.read(getClass().getResource(path));
	}
	public void rotateLeft(boolean car1){
		if (car1) {

				Timer timer = new Timer();
				timer.schedule( new TimerTask() {
					public void run() {
						if (!playerOneRotateLeft) {
							timer.cancel();
						}
						player1.setRotation(player1.getRotation() - 1);
						// do your work
					}
				}, 0, 100);
		}
		else{
			Timer timer = new Timer();
			timer.schedule( new TimerTask() {
				public void run() {
					if (!isRotatingLeft) {
						timer.cancel();
					}
					player2.setRotation(player2.getRotation() - 1);
					// do your work
				}
			}, 0, 100);
		}
	}
	public void rotateRight(boolean car1){
		if (car1) {

			Timer timer = new Timer();
			timer.schedule( new TimerTask() {
				public void run() {
					if (!playerOneRotateRight) {
						timer.cancel();
					}
					player1.setRotation(player1.getRotation() + 1);
					// do your work
				}
			}, 0, 100);
		}
		else{
			Timer timer = new Timer();
			timer.schedule( new TimerTask() {
				public void run() {
					if (!isRotatingRight) {
						timer.cancel();
					}
					player2.setRotation(player2.getRotation() + 1);
					// do your work
				}
			}, 0, 100);
		}
	}
	public void movePlayer(boolean playerOne,boolean forward){
		if (playerOne){
			if (forward){
				player1.setxPos(player1.getxPos() + (int) player1.getVelocityX());
				player1.setyPos(player1.getyPos() + (int) player1.getVelocityY());
			}
			else{
				player1.setxPos(player1.getxPos() - (int) player1.getVelocityX());
				player1.setyPos(player1.getyPos() - (int) player1.getVelocityY());
			}
		}
		else{
			if (forward){
				player2.setxPos(player2.getxPos() + (int) player2.getVelocityX());
				player2.setyPos(player2.getyPos() + (int) player2.getVelocityY());
			}
			else{
				player2.setxPos(player2.getxPos() - (int) player2.getVelocityX());
				player2.setyPos(player2.getyPos() - (int) player2.getVelocityY());
			}
		}
	}
	public void changeVelocity(boolean x){
		if (x) {
			if (player1.getRotation() >= 170 & player1.getRotation() < 260) {
				player1.setVelocityX(0);
				player1.setVelocityY(-2);
			}
			if (player1.getRotation() >= 80 & player1.getRotation() < 170) {
				player1.setVelocityY(0);
				player1.setVelocityX(-2);
			}
			if (player1.getRotation() >= 0 & player1.getRotation() < 80) {
				player1.setVelocityX(0);
				player1.setVelocityY(2);
			}
			if (player1.getRotation() >= 260 & player1.getRotation() < 360) {
				player1.setVelocityY(0);
				player1.setVelocityX(2);
			}
		}
		else{
			if (player2.getRotation() >= 170 & player2.getRotation() < 260) {
				player2.setVelocityX(0);
				player2.setVelocityY(-2);
			}
			if (player2.getRotation() >= 80 & player2.getRotation() < 170) {
				player2.setVelocityY(0);
				player2.setVelocityX(-2);
			}
			if (player2.getRotation() >= 0 & player2.getRotation() < 80) {
				player2.setVelocityX(0);
				player2.setVelocityY(2);
			}
			if (player2.getRotation() >= 260 & player2.getRotation() < 360) {
				player2.setVelocityY(0);
				player2.setVelocityX(2);
			}
		}

	}
	public void resetVelocity(boolean x){
		if (x) {
			player1.setVelocityX(0);
			player1.setVelocityY(0);
		}
		else {
			player2.setVelocityY(0);
			player2.setVelocityX(0);
		}
	}
}
