package main;

import java.awt.Dimension;

import javax.swing.JFrame;

import game.Game;
import game.Input;

public class Main {

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		Game game = new Game();
		frame.add(game);
		frame.addKeyListener(new Input(game));
		frame.setFocusable(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(Game.WIDTH, Game.HEIGHT);
		frame.setVisible(true);
		game.start();

	}

}
